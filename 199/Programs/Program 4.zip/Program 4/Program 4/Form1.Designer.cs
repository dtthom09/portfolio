﻿namespace Program_4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelOriginZIp = new System.Windows.Forms.Label();
            this.labelDestZip = new System.Windows.Forms.Label();
            this.labelLength = new System.Windows.Forms.Label();
            this.labelWidth = new System.Windows.Forms.Label();
            this.labelHeight = new System.Windows.Forms.Label();
            this.labelWeight = new System.Windows.Forms.Label();
            this.textBoxOriginZip = new System.Windows.Forms.TextBox();
            this.textBoxDestZip = new System.Windows.Forms.TextBox();
            this.textBoxLength = new System.Windows.Forms.TextBox();
            this.textBoxWidth = new System.Windows.Forms.TextBox();
            this.textBoxHeight = new System.Windows.Forms.TextBox();
            this.textBoxWeight = new System.Windows.Forms.TextBox();
            this.buttonGroundPackage = new System.Windows.Forms.Button();
            this.listBoxPackage = new System.Windows.Forms.ListBox();
            this.buttonDetails = new System.Windows.Forms.Button();
            this.buttonSendToUofL = new System.Windows.Forms.Button();
            this.buttonSendFromUofL = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelOriginZIp
            // 
            this.labelOriginZIp.AutoSize = true;
            this.labelOriginZIp.Location = new System.Drawing.Point(12, 9);
            this.labelOriginZIp.Name = "labelOriginZIp";
            this.labelOriginZIp.Size = new System.Drawing.Size(55, 13);
            this.labelOriginZIp.TabIndex = 0;
            this.labelOriginZIp.Text = "Origin Zip:";
            // 
            // labelDestZip
            // 
            this.labelDestZip.AutoSize = true;
            this.labelDestZip.Location = new System.Drawing.Point(14, 37);
            this.labelDestZip.Name = "labelDestZip";
            this.labelDestZip.Size = new System.Drawing.Size(53, 13);
            this.labelDestZip.TabIndex = 1;
            this.labelDestZip.Text = "Dest. Zip:";
            // 
            // labelLength
            // 
            this.labelLength.AutoSize = true;
            this.labelLength.Location = new System.Drawing.Point(24, 65);
            this.labelLength.Name = "labelLength";
            this.labelLength.Size = new System.Drawing.Size(43, 13);
            this.labelLength.TabIndex = 2;
            this.labelLength.Text = "Length:";
            // 
            // labelWidth
            // 
            this.labelWidth.AutoSize = true;
            this.labelWidth.Location = new System.Drawing.Point(29, 95);
            this.labelWidth.Name = "labelWidth";
            this.labelWidth.Size = new System.Drawing.Size(38, 13);
            this.labelWidth.TabIndex = 3;
            this.labelWidth.Text = "Width:";
            // 
            // labelHeight
            // 
            this.labelHeight.AutoSize = true;
            this.labelHeight.Location = new System.Drawing.Point(26, 123);
            this.labelHeight.Name = "labelHeight";
            this.labelHeight.Size = new System.Drawing.Size(41, 13);
            this.labelHeight.TabIndex = 4;
            this.labelHeight.Text = "Height:";
            // 
            // labelWeight
            // 
            this.labelWeight.AutoSize = true;
            this.labelWeight.Location = new System.Drawing.Point(23, 153);
            this.labelWeight.Name = "labelWeight";
            this.labelWeight.Size = new System.Drawing.Size(44, 13);
            this.labelWeight.TabIndex = 5;
            this.labelWeight.Text = "Weight:";
            // 
            // textBoxOriginZip
            // 
            this.textBoxOriginZip.Location = new System.Drawing.Point(73, 6);
            this.textBoxOriginZip.Name = "textBoxOriginZip";
            this.textBoxOriginZip.Size = new System.Drawing.Size(100, 20);
            this.textBoxOriginZip.TabIndex = 6;
            // 
            // textBoxDestZip
            // 
            this.textBoxDestZip.Location = new System.Drawing.Point(73, 34);
            this.textBoxDestZip.Name = "textBoxDestZip";
            this.textBoxDestZip.Size = new System.Drawing.Size(100, 20);
            this.textBoxDestZip.TabIndex = 7;
            // 
            // textBoxLength
            // 
            this.textBoxLength.Location = new System.Drawing.Point(73, 62);
            this.textBoxLength.Name = "textBoxLength";
            this.textBoxLength.Size = new System.Drawing.Size(100, 20);
            this.textBoxLength.TabIndex = 8;
            // 
            // textBoxWidth
            // 
            this.textBoxWidth.Location = new System.Drawing.Point(73, 92);
            this.textBoxWidth.Name = "textBoxWidth";
            this.textBoxWidth.Size = new System.Drawing.Size(100, 20);
            this.textBoxWidth.TabIndex = 9;
            // 
            // textBoxHeight
            // 
            this.textBoxHeight.Location = new System.Drawing.Point(73, 120);
            this.textBoxHeight.Name = "textBoxHeight";
            this.textBoxHeight.Size = new System.Drawing.Size(100, 20);
            this.textBoxHeight.TabIndex = 10;
            // 
            // textBoxWeight
            // 
            this.textBoxWeight.Location = new System.Drawing.Point(73, 150);
            this.textBoxWeight.Name = "textBoxWeight";
            this.textBoxWeight.Size = new System.Drawing.Size(100, 20);
            this.textBoxWeight.TabIndex = 11;
            // 
            // buttonGroundPackage
            // 
            this.buttonGroundPackage.AutoSize = true;
            this.buttonGroundPackage.Location = new System.Drawing.Point(63, 187);
            this.buttonGroundPackage.Name = "buttonGroundPackage";
            this.buttonGroundPackage.Size = new System.Drawing.Size(120, 23);
            this.buttonGroundPackage.TabIndex = 12;
            this.buttonGroundPackage.Text = "Add Ground Package";
            this.buttonGroundPackage.UseVisualStyleBackColor = true;
            this.buttonGroundPackage.Click += new System.EventHandler(this.buttonGroundPackage_Click);
            // 
            // listBoxPackage
            // 
            this.listBoxPackage.FormattingEnabled = true;
            this.listBoxPackage.Location = new System.Drawing.Point(203, 6);
            this.listBoxPackage.Name = "listBoxPackage";
            this.listBoxPackage.Size = new System.Drawing.Size(135, 160);
            this.listBoxPackage.TabIndex = 13;
            // 
            // buttonDetails
            // 
            this.buttonDetails.Location = new System.Drawing.Point(344, 12);
            this.buttonDetails.Name = "buttonDetails";
            this.buttonDetails.Size = new System.Drawing.Size(91, 23);
            this.buttonDetails.TabIndex = 14;
            this.buttonDetails.Text = "Details";
            this.buttonDetails.UseVisualStyleBackColor = true;
            this.buttonDetails.Click += new System.EventHandler(this.buttonDetails_Click);
            // 
            // buttonSendToUofL
            // 
            this.buttonSendToUofL.Location = new System.Drawing.Point(344, 75);
            this.buttonSendToUofL.Name = "buttonSendToUofL";
            this.buttonSendToUofL.Size = new System.Drawing.Size(91, 23);
            this.buttonSendToUofL.TabIndex = 15;
            this.buttonSendToUofL.Text = "Send to UofL";
            this.buttonSendToUofL.UseVisualStyleBackColor = true;
            this.buttonSendToUofL.Click += new System.EventHandler(this.buttonSendToUofL_Click);
            // 
            // buttonSendFromUofL
            // 
            this.buttonSendFromUofL.AutoSize = true;
            this.buttonSendFromUofL.Location = new System.Drawing.Point(344, 143);
            this.buttonSendFromUofL.Name = "buttonSendFromUofL";
            this.buttonSendFromUofL.Size = new System.Drawing.Size(91, 23);
            this.buttonSendFromUofL.TabIndex = 16;
            this.buttonSendFromUofL.Text = "Send from UofL";
            this.buttonSendFromUofL.UseVisualStyleBackColor = true;
            this.buttonSendFromUofL.Click += new System.EventHandler(this.buttonSendFromUofL_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(442, 233);
            this.Controls.Add(this.buttonSendFromUofL);
            this.Controls.Add(this.buttonSendToUofL);
            this.Controls.Add(this.buttonDetails);
            this.Controls.Add(this.listBoxPackage);
            this.Controls.Add(this.buttonGroundPackage);
            this.Controls.Add(this.textBoxWeight);
            this.Controls.Add(this.textBoxHeight);
            this.Controls.Add(this.textBoxWidth);
            this.Controls.Add(this.textBoxLength);
            this.Controls.Add(this.textBoxDestZip);
            this.Controls.Add(this.textBoxOriginZip);
            this.Controls.Add(this.labelWeight);
            this.Controls.Add(this.labelHeight);
            this.Controls.Add(this.labelWidth);
            this.Controls.Add(this.labelLength);
            this.Controls.Add(this.labelDestZip);
            this.Controls.Add(this.labelOriginZIp);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelOriginZIp;
        private System.Windows.Forms.Label labelDestZip;
        private System.Windows.Forms.Label labelLength;
        private System.Windows.Forms.Label labelWidth;
        private System.Windows.Forms.Label labelHeight;
        private System.Windows.Forms.Label labelWeight;
        private System.Windows.Forms.TextBox textBoxOriginZip;
        private System.Windows.Forms.TextBox textBoxDestZip;
        private System.Windows.Forms.TextBox textBoxLength;
        private System.Windows.Forms.TextBox textBoxWidth;
        private System.Windows.Forms.TextBox textBoxHeight;
        private System.Windows.Forms.TextBox textBoxWeight;
        private System.Windows.Forms.Button buttonGroundPackage;
        private System.Windows.Forms.ListBox listBoxPackage;
        private System.Windows.Forms.Button buttonDetails;
        private System.Windows.Forms.Button buttonSendToUofL;
        private System.Windows.Forms.Button buttonSendFromUofL;
    }
}

