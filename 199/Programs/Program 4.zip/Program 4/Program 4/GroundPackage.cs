﻿//Dylan Thomas
//CIS 199-01
// 4-24-16
//Program 4

//File: GroundPackage.cs
//This file creates a GrounPackage class capable of producing
// a package cost based on its origin zip, destination zip, 
// length, width, height, and weight.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_4
{
    class GroundPackage
    {
        private int _originzip;         //Origin zip for package.
        private int _destinationzip;    //Destination zip for package.
        private double _length;         //Length for package.
        private double _width;          //Width for package.
        private double _height;         //Height for package.   
        private double _weight;         //Weight for package.
        private double _cost;           //Cost to ship package.

        //Precondition: Origin zip and destination zip have 5 numbers.
                        //Length, width, height, and weight are greater than 0.
        //Postcondition: The package has been initialized with the specified values
                         //for origin zip, destination zip, length, width, height, and weight.
        public GroundPackage(int o, int d, double l, double wid, double h, double wei)
        {
            //Properties to set in case invalid data sent.
            OriginZip = o;
            DestinationZip = d;
            Length = l;
            Width = wid;
            Height = h;
            Weight = wei;
        }

        public int OriginZip
        {
            //Precondition: None
            //Postcondition: The origin zip has been returned
            get
            {
                return _originzip;
            }
            //Precondition: Value length is equal to 5
            //Postcondition: The origin zip has been set to the specified value
            set
            {
                if (value.ToString().Length == 5)
                    _originzip = value;
            }
        }
        public int DestinationZip
        {
            //Precondition: None
            //Postcondition: The destination zip has been returned.
            get
            {
                return _destinationzip;
            }
            //Precondition: value length is equal to 5
            //Postcondition: The destination zip has been set to the specified value
            set
            {
                if (value.ToString().Length == 5)
                    _destinationzip = value;
            }
        }
        public double Length
        {
            //Precondition: None
            //Postcondition: The length has been returned.
            get
            {
                return _length;
            }
            //Precondition: The value is greater than 0
            //Postcondition: The length has been set to the specified value
            set
            {
                if (value > 0)
                    _length = value;
            }
        }
        public double Width
        {
            //Precondition: None
            //Postcondition: The width has been returned.
            get
            {
                return _width;
            }
            //Precondition: The value is greater than 0
            //Postcondition: The width has been set to the specified value
            set
            {
                if (value > 0)
                    _width = value;
            }
        }
        public double Height
        {
            //Precondition: None
            //Postcondition: The height has been returned.
            get
            {
                return _height;
            }
            //Precondition: The value is greater than 0
            //Postcondition: The height has been set to the specified value
            set
            {
                if (value > 0)
                    _height = value;
            }
        }
        public double Weight
        {
            //Precondition: None
            //Postcondition: The weight has been returned.
            get
            {
                return _weight;
            }
            //Precondition: The value is greater than 0
            //Postcondition: The weight has been set to the specified value
            set
            {
                if (value > 0)
                    _weight = value;
            }
        }
        public int ZoneDistance
        {
            //Precondition: Origin zip and destination zip have been declared.
            //Postcondition: The positive difference between the first digit of origin zip and destination zip has been returned.
            get
            {
                return Math.Abs((OriginZip / 10000) - (DestinationZip / 10000));
            }
        }
        //Precondition: Length, width, height, zonedistance, and weight contain numerical data.
        //Postcondition: The cost value is returned
        public double CalcCost()
        {
                _cost = (.20 * (Length + Width + Height) + .5 * (ZoneDistance + 1) * (Weight));
                _cost.ToString("C");
                return _cost;
        }
        //Precondition: none
        //Postcondition: A strind is returned displaying the packages details on seperate lines.
        public override string ToString()
        {
            string result;

            result = "Original Zipcode: " + OriginZip.ToString("D5") + System.Environment.NewLine +
            "Destination Zipcode: " + DestinationZip.ToString("D5") + System.Environment.NewLine +
            "Length: " + Length.ToString() + System.Environment.NewLine +
            "Width: " + Width.ToString() + System.Environment.NewLine +
            "Height: " + Height.ToString() + System.Environment.NewLine +
            "Weight: " + Weight.ToString();

            return result;
        }
    }
}
