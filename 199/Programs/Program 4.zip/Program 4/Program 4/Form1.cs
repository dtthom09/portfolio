﻿//Dylan Thomas
//CIS 199-01
// 4-24-16
//Program 4

//This class creates a groundpackage price and displays it in a listbox.
//It can display its discription with a click of the display button.
//The zip can easily be changed to Uofl's zip, 40292.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program_4
{
    public partial class Form1 : Form
    {
        private List<GroundPackage> packageList = new List<GroundPackage>();
        //Precondition: None
        //Postcondition: Form is constructed and ready to go
        public Form1()
        {
            InitializeComponent();
        }
        const int zip = 40292;  //Uofl's zipcode
        //Precondition: User clicked the Add ground package button.
        //Postcondition: Form's package list box displays the price for an object if the user enters a numerical value,
        //               otherwise an error message is displayed.
        private void buttonGroundPackage_Click(object sender, EventArgs e)
        {
            int originZip;  //Origin value to set.
            int destZip;    //Destination value to set.
            double length;  //Length value to set.
            double width;   //Width value to set.
            double height;  //Height value to set.
            double weight;  //Width value to set.

            //Testing to see if user inputed numerical data.
            if (int.TryParse(textBoxOriginZip.Text, out originZip))
            {
                if (int.TryParse(textBoxDestZip.Text, out destZip))
                {
                    if (double.TryParse(textBoxLength.Text, out length))
                    {
                        if (double.TryParse(textBoxWidth.Text, out width))
                        {
                            if (double.TryParse(textBoxHeight.Text, out height))
                            {
                                if (double.TryParse(textBoxWeight.Text, out weight))
                                {
                                    //Constructor
                                    GroundPackage package = new GroundPackage(originZip, destZip, length, width, height, weight);

                                    //Setting the value from the textbox equel to that in the GroundPackage class.
                                    package.OriginZip = originZip;
                                    package.DestinationZip = destZip;
                                    package.Length = length;
                                    package.Width = width;
                                    package.Height = height;
                                    package.Weight = weight;

                                    packageList.Add(package);   //Adds a package to the package list.

                                    listBoxPackage.Items.Add(package.CalcCost());   //Adds the packages cost to the list box.

                                    //Clears textboxes
                                    textBoxOriginZip.Clear();
                                    textBoxDestZip.Clear();
                                    textBoxLength.Clear();
                                    textBoxWidth.Clear();
                                    textBoxHeight.Clear();
                                    textBoxWeight.Clear();


                                }
                                else
                                {
                                    MessageBox.Show("Enter a valid weight.");
                                }
                            }
                            else
                            {
                                MessageBox.Show("Enter a valid height.");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Enter a valid width.");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Enter a valid length.");
                    }
                }
                else
                {
                    MessageBox.Show("Enter a valid destination zip.");
                }
            }
            else
            {
                MessageBox.Show("Enter a valid origin zip");
            }
        }

        //Precondition: User clicks a package and then clicks on details button.
        //Postcondition: The packages details are displayed.
        private void buttonDetails_Click(object sender, EventArgs e)
        {
            if (listBoxPackage.SelectedIndex == -1)
            {
                MessageBox.Show("No package has been selected.");
            }
            else
            {
                int index = listBoxPackage.SelectedIndex;

                MessageBox.Show(packageList[index].ToString());
            }
        }

        //Precondition: User clicks a package and then clicks send to UofL button.
        //Postcondition: The destination zip is changed to 40292 and the cost is updated.
        private void buttonSendToUofL_Click(object sender, EventArgs e)
        {
            if (listBoxPackage.SelectedIndex == -1)
            {
                MessageBox.Show("No package has been selected.");
            }
            else
            {

                int index = listBoxPackage.SelectedIndex;

                packageList[index].DestinationZip = zip;

                listBoxPackage.Items[index] = packageList[index].CalcCost();

                MessageBox.Show("The package's destination zip has been changed to 40292");
            }
        }

        //Precondition: The user clicks a package and then clicks senf from UofL button.
        //Postcondition: The origin zip is updated and the cost is updated.
        private void buttonSendFromUofL_Click(object sender, EventArgs e)
        {
            if (listBoxPackage.SelectedIndex == -1)
            {
                MessageBox.Show("No package has been selected.");
            }
            else
            {
                int index = listBoxPackage.SelectedIndex;

                packageList[index].OriginZip = zip;

                listBoxPackage.Items[index] = packageList[index].CalcCost();

                MessageBox.Show("The package's orign zip has been changed to 40292");
            }
        }
    }
}
