﻿//By: Dylan Thomas
//CIS 199-01
//Program 2
//3/6/16
/*This program was created to tell you when to sign up for classes for spring 2016 based on how many credits you have earned and the first letter of your last name */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program_2
{
    public partial class Program2 : Form
    {
        public Program2()
        {
            InitializeComponent();
        }

        private void buttonOK_Click(object sender, EventArgs e)
        {
            int SENIOR = 90;    //Senior credit hour variable.
            int JUNIOR = 60;    //Junior credit hour variable. 
            int SOPHOMORE = 30; //Sophomore credit hour variable.
            double hours;       //To hold the number of credit hours earned.
            string letter;      //To hold the first letter of the user's last name.
            string lastname;    //To hold the user's last name.

            //Validate the user entered something into the textboxlastname control.
                if (textBoxlastname.Text == "")
                    MessageBox.Show("First letter of last name text box left blank.");
                else
                {
                    //Validate the textboxcredhours control.
                    if (double.TryParse(textBoxcredhours.Text, out hours))
                    {
                        lastname = textBoxlastname.Text;  //Turn the text typed into textboxlastname control into the letter string.
                        letter = lastname.Substring(0, 1);  //Take the first letter of the last name string.
                        letter = letter.ToUpper();  //To convert any letter typed into the textboxlastname control into an uppercase letter.

                        if (hours >= 0)
                        {
                            if (hours >= JUNIOR)
                            {
                                //Determine the day to register.
                                {
                                    if (hours >= SENIOR)
                                        outputlabelearliestday.Text = "March 30";
                                }
                                    if (hours >= JUNIOR && hours < SENIOR)
                                {
                                    outputlabelearliestday.Text = "March 31";
                                }
                                //Determine the time the user is eligible to register for classes.
                                switch (letter)
                                {
                                    case "A":
                                    case "B":
                                    case "C":
                                    case "D":

                                        outputlabelearliesttime.Text = "4:00p.m.";
                                        break;

                                    case "E":
                                    case "F":
                                    case "G":
                                    case "H":
                                    case "I":

                                        outputlabelearliesttime.Text = "8:30a.m.";
                                        break;

                                    case "J":
                                    case "K":
                                    case "L":
                                    case "M":
                                    case "N":
                                    case "O":

                                        outputlabelearliesttime.Text = "10:00a.m.";
                                        break;

                                    case "P":
                                    case "Q":
                                    case "R":
                                    case "S":

                                        outputlabelearliesttime.Text = "11:30a.m.";
                                        break;

                                    case "T":
                                    case "U":
                                    case "V":
                                    case "W":
                                    case "X":
                                    case "Y":
                                    case "Z":

                                        outputlabelearliesttime.Text = "2:00p.m.";
                                        break;


                                }
                            }
                            else
                            {
                                {
                                    //Determine the day to register.
                                    if (hours >= SOPHOMORE && (string.Compare(letter, "D") > 0) && (string.Compare(letter, "R") < 0))
                                    {
                                        outputlabelearliestday.Text = "April 1";
                                    }
                                    else if (hours >= SOPHOMORE)
                                    {
                                        outputlabelearliestday.Text = "April 4";
                                    }
                                    else if ((string.Compare(letter, "D") > 0) && (string.Compare(letter, "R") < 0))
                                    {
                                        outputlabelearliestday.Text = "April 5";
                                    }
                                    else
                                    {
                                        outputlabelearliestday.Text = "April 6";
                                    }
                                }
                                //Determine the time the user is eligible to register for classes.
                                switch (letter)
                                {
                                    case "A":
                                    case "B":

                                        outputlabelearliesttime.Text = "2:00p.m.";
                                        break;

                                    case "C":
                                    case "D":

                                        outputlabelearliesttime.Text = "4:00p.m.";
                                        break;

                                    case "E":
                                    case "F":

                                        outputlabelearliesttime.Text = "8:30a.m.";
                                        break;

                                    case "G":
                                    case "H":
                                    case "I":

                                        outputlabelearliesttime.Text = "10:00a.m.";
                                        break;

                                    case "J":
                                    case "K":
                                    case "L":

                                        outputlabelearliesttime.Text = "11:30a.m.";
                                        break;

                                    case "M":
                                    case "N":
                                    case "O":

                                        outputlabelearliesttime.Text = "2:00p.m.";
                                        break;

                                    case "P":
                                    case "Q":

                                        outputlabelearliesttime.Text = "4:00p.m.";
                                        break;

                                    case "R":
                                    case "S":

                                        outputlabelearliesttime.Text = "8:30a.m.";
                                        break;

                                    case "T":
                                    case "U":
                                    case "V":

                                        outputlabelearliesttime.Text = "10:00a.m.";
                                        break;

                                    case "W":
                                    case "X":
                                    case "Y":
                                    case "Z":

                                        outputlabelearliesttime.Text = "11:30a.m.";
                                        break;
                                }
                            }
                        }
                        else
                        {
                            //Display an error for invalid # of credit hours.
                            MessageBox.Show("Credit hours can't be less than 0.");
                        }
                    }
                    else
                    {
                        //Display an error message for hoursTextBox.
                        MessageBox.Show("Invalid input for hours.");
                    }
                }
            
            }
        }
    }
