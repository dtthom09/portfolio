﻿namespace Program_2
{
    partial class Program2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelcredhours = new System.Windows.Forms.Label();
            this.textBoxcredhours = new System.Windows.Forms.TextBox();
            this.labellastname = new System.Windows.Forms.Label();
            this.textBoxlastname = new System.Windows.Forms.TextBox();
            this.labelearliesday = new System.Windows.Forms.Label();
            this.labelearliestime = new System.Windows.Forms.Label();
            this.outputlabelearliestday = new System.Windows.Forms.Label();
            this.outputlabelearliesttime = new System.Windows.Forms.Label();
            this.buttonOK = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelcredhours
            // 
            this.labelcredhours.AutoSize = true;
            this.labelcredhours.Location = new System.Drawing.Point(12, 28);
            this.labelcredhours.Name = "labelcredhours";
            this.labelcredhours.Size = new System.Drawing.Size(153, 13);
            this.labelcredhours.TabIndex = 0;
            this.labelcredhours.Text = "Number of earned credit hours:";
            // 
            // textBoxcredhours
            // 
            this.textBoxcredhours.Location = new System.Drawing.Point(171, 25);
            this.textBoxcredhours.Name = "textBoxcredhours";
            this.textBoxcredhours.Size = new System.Drawing.Size(100, 20);
            this.textBoxcredhours.TabIndex = 1;
            // 
            // labellastname
            // 
            this.labellastname.AutoSize = true;
            this.labellastname.Location = new System.Drawing.Point(50, 64);
            this.labellastname.Name = "labellastname";
            this.labellastname.Size = new System.Drawing.Size(115, 13);
            this.labellastname.TabIndex = 2;
            this.labellastname.Text = "First letter of last name:";
            // 
            // textBoxlastname
            // 
            this.textBoxlastname.Location = new System.Drawing.Point(171, 61);
            this.textBoxlastname.Name = "textBoxlastname";
            this.textBoxlastname.Size = new System.Drawing.Size(100, 20);
            this.textBoxlastname.TabIndex = 3;
            // 
            // labelearliesday
            // 
            this.labelearliesday.AutoSize = true;
            this.labelearliesday.Location = new System.Drawing.Point(52, 100);
            this.labelearliesday.Name = "labelearliesday";
            this.labelearliesday.Size = new System.Drawing.Size(113, 13);
            this.labelearliesday.TabIndex = 4;
            this.labelearliesday.Text = "Earliest day to register:";
            // 
            // labelearliestime
            // 
            this.labelearliestime.AutoSize = true;
            this.labelearliestime.Location = new System.Drawing.Point(50, 136);
            this.labelearliestime.Name = "labelearliestime";
            this.labelearliestime.Size = new System.Drawing.Size(115, 13);
            this.labelearliestime.TabIndex = 5;
            this.labelearliestime.Text = "Earliest time to register:";
            // 
            // outputlabelearliestday
            // 
            this.outputlabelearliestday.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputlabelearliestday.Location = new System.Drawing.Point(171, 99);
            this.outputlabelearliestday.Name = "outputlabelearliestday";
            this.outputlabelearliestday.Size = new System.Drawing.Size(100, 23);
            this.outputlabelearliestday.TabIndex = 6;
            // 
            // outputlabelearliesttime
            // 
            this.outputlabelearliesttime.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputlabelearliesttime.Location = new System.Drawing.Point(171, 135);
            this.outputlabelearliesttime.Name = "outputlabelearliesttime";
            this.outputlabelearliesttime.Size = new System.Drawing.Size(100, 23);
            this.outputlabelearliesttime.TabIndex = 7;
            // 
            // buttonOK
            // 
            this.buttonOK.Location = new System.Drawing.Point(70, 188);
            this.buttonOK.Name = "buttonOK";
            this.buttonOK.Size = new System.Drawing.Size(75, 23);
            this.buttonOK.TabIndex = 8;
            this.buttonOK.Text = "OK";
            this.buttonOK.UseVisualStyleBackColor = true;
            this.buttonOK.Click += new System.EventHandler(this.buttonOK_Click);
            // 
            // Program2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 273);
            this.Controls.Add(this.buttonOK);
            this.Controls.Add(this.outputlabelearliesttime);
            this.Controls.Add(this.outputlabelearliestday);
            this.Controls.Add(this.labelearliestime);
            this.Controls.Add(this.labelearliesday);
            this.Controls.Add(this.textBoxlastname);
            this.Controls.Add(this.labellastname);
            this.Controls.Add(this.textBoxcredhours);
            this.Controls.Add(this.labelcredhours);
            this.Name = "Program2";
            this.Text = "Program 2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelcredhours;
        private System.Windows.Forms.TextBox textBoxcredhours;
        private System.Windows.Forms.Label labellastname;
        private System.Windows.Forms.TextBox textBoxlastname;
        private System.Windows.Forms.Label labelearliesday;
        private System.Windows.Forms.Label labelearliestime;
        private System.Windows.Forms.Label outputlabelearliestday;
        private System.Windows.Forms.Label outputlabelearliesttime;
        private System.Windows.Forms.Button buttonOK;
    }
}

