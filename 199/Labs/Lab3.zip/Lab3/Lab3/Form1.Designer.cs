﻿namespace Lab3
{
    partial class Lab3Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblMealPrice = new System.Windows.Forms.Label();
            this.Lbl15pct = new System.Windows.Forms.Label();
            this.Lbl18Pct = new System.Windows.Forms.Label();
            this.Lbl20pct = new System.Windows.Forms.Label();
            this.TxtboxMealPrice = new System.Windows.Forms.TextBox();
            this.Txtbox15pctOutput = new System.Windows.Forms.Label();
            this.Txtbox18pctOutput = new System.Windows.Forms.Label();
            this.Txtbox20pctOutput = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LblMealPrice
            // 
            this.LblMealPrice.AutoSize = true;
            this.LblMealPrice.Location = new System.Drawing.Point(57, 17);
            this.LblMealPrice.Name = "LblMealPrice";
            this.LblMealPrice.Size = new System.Drawing.Size(100, 13);
            this.LblMealPrice.TabIndex = 0;
            this.LblMealPrice.Text = "Enter Price of Meal:";
            // 
            // Lbl15pct
            // 
            this.Lbl15pct.AutoSize = true;
            this.Lbl15pct.Location = new System.Drawing.Point(130, 65);
            this.Lbl15pct.Name = "Lbl15pct";
            this.Lbl15pct.Size = new System.Drawing.Size(27, 13);
            this.Lbl15pct.TabIndex = 1;
            this.Lbl15pct.Text = "15%";
            // 
            // Lbl18Pct
            // 
            this.Lbl18Pct.AutoSize = true;
            this.Lbl18Pct.Location = new System.Drawing.Point(130, 105);
            this.Lbl18Pct.Name = "Lbl18Pct";
            this.Lbl18Pct.Size = new System.Drawing.Size(27, 13);
            this.Lbl18Pct.TabIndex = 2;
            this.Lbl18Pct.Text = "18%";
            // 
            // Lbl20pct
            // 
            this.Lbl20pct.AutoSize = true;
            this.Lbl20pct.Location = new System.Drawing.Point(130, 145);
            this.Lbl20pct.Name = "Lbl20pct";
            this.Lbl20pct.Size = new System.Drawing.Size(27, 13);
            this.Lbl20pct.TabIndex = 3;
            this.Lbl20pct.Text = "20%";
            // 
            // TxtboxMealPrice
            // 
            this.TxtboxMealPrice.Location = new System.Drawing.Point(163, 14);
            this.TxtboxMealPrice.Name = "TxtboxMealPrice";
            this.TxtboxMealPrice.Size = new System.Drawing.Size(100, 20);
            this.TxtboxMealPrice.TabIndex = 4;
            // 
            // Txtbox15pctOutput
            // 
            this.Txtbox15pctOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Txtbox15pctOutput.Location = new System.Drawing.Point(163, 55);
            this.Txtbox15pctOutput.Name = "Txtbox15pctOutput";
            this.Txtbox15pctOutput.Size = new System.Drawing.Size(100, 23);
            this.Txtbox15pctOutput.TabIndex = 5;
            // 
            // Txtbox18pctOutput
            // 
            this.Txtbox18pctOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Txtbox18pctOutput.Location = new System.Drawing.Point(163, 95);
            this.Txtbox18pctOutput.Name = "Txtbox18pctOutput";
            this.Txtbox18pctOutput.Size = new System.Drawing.Size(100, 23);
            this.Txtbox18pctOutput.TabIndex = 6;
            // 
            // Txtbox20pctOutput
            // 
            this.Txtbox20pctOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Txtbox20pctOutput.Location = new System.Drawing.Point(163, 135);
            this.Txtbox20pctOutput.Name = "Txtbox20pctOutput";
            this.Txtbox20pctOutput.Size = new System.Drawing.Size(100, 23);
            this.Txtbox20pctOutput.TabIndex = 7;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(109, 198);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(80, 23);
            this.button1.TabIndex = 8;
            this.button1.Text = "Calculate Tip";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Lab3Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 273);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Txtbox20pctOutput);
            this.Controls.Add(this.Txtbox18pctOutput);
            this.Controls.Add(this.Txtbox15pctOutput);
            this.Controls.Add(this.TxtboxMealPrice);
            this.Controls.Add(this.Lbl20pct);
            this.Controls.Add(this.Lbl18Pct);
            this.Controls.Add(this.Lbl15pct);
            this.Controls.Add(this.LblMealPrice);
            this.Name = "Lab3Form";
            this.Text = "Lab 3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblMealPrice;
        private System.Windows.Forms.Label Lbl15pct;
        private System.Windows.Forms.Label Lbl18Pct;
        private System.Windows.Forms.Label Lbl20pct;
        private System.Windows.Forms.TextBox TxtboxMealPrice;
        private System.Windows.Forms.Label Txtbox15pctOutput;
        private System.Windows.Forms.Label Txtbox18pctOutput;
        private System.Windows.Forms.Label Txtbox20pctOutput;
        private System.Windows.Forms.Button button1;
    }
}

