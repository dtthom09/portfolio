﻿//Dylan Thomas
//Lab3
//CIS 199-01
//2-9-16
/*This application was created to determine the ammount to tip for a low, middle, and high tip based on the meal price typed in the text box. */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab3
{
    public partial class Lab3Form : Form
    {
        public Lab3Form()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            decimal MealPrice;     //The meal's original price.
            decimal LOWTIPRATE = .15m;    //The price of a tip at the low rate.
            decimal MIDTIPRATE = .18m;     //The price of a tip at the middle rate.
            decimal HIGHTIPRATE = .20m;    //The price of a tip at the high rate.

            MealPrice = decimal.Parse(TxtboxMealPrice.Text);  //Get the meal's original price.

            LOWTIPRATE = MealPrice * LOWTIPRATE;    //Set the low tip rate equal to the meal price multiplied by the lowtiprate decimal.

            Txtbox15pctOutput.Text = LOWTIPRATE.ToString("c");  //Display the low tip rate.

            MIDTIPRATE = MealPrice * MIDTIPRATE;    //Set the mid tip rate equal to the meal price multiplied by the midtiprate decimal.

            Txtbox18pctOutput.Text = MIDTIPRATE.ToString("c");  //Display the middle tip rate.

            HIGHTIPRATE = MealPrice * HIGHTIPRATE;  //Set the high tip rate equal to the meal price multiplied by the hightiprate decimal.

            Txtbox20pctOutput.Text = HIGHTIPRATE.ToString("c"); //Display the high tip rate.

        }
    }
}
