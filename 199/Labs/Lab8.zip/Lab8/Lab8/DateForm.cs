﻿//Dylan Thomas
//CIS199-01
//Lab8
//4-19-16
//In lab8 we made a form that would allow you to type in a month, date, and/or year 
//into seperate textboxes, displaying the overall date in a label.
//We made a class aside from the form class to store all the date logic in.
//We made this class to where it could be incorporated into various applications.
//The form is made to update the month, day, or year in the ouputlabel with what is entered 
//into the textbox.  It then clears the textbox.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab8
{
    public partial class DateForm : Form
    {
        //Date field with a starting date of 01/01/2000
        private Date date = new Date(1, 1, 2000);

        public DateForm()
        {
            InitializeComponent();
        }
        private void Lab8_Load(object sender, EventArgs e)
        {
            //Display the date.
            labelOutputDate.Text = date.ToString();
        }

        //Precondition: Update Month button clicked.
        //Postcondition: Month is validated and then updated on the date label.
        //               The month textbox is then cleared.
        private void buttonMonth_Click(object sender, EventArgs e)
        {
            int month;  //To hold the variable for month.

            //Convert the amount to an int.
            if (int.TryParse(textBoxMonth.Text, out month))
            {
                //Input the month into the date variable.
                date.Month = month;

                //Display the month.
                labelOutputDate.Text = date.ToString();

                //Clear the text box.
                textBoxMonth.Clear();
            }
            else
            {
                //Display an error message.
                MessageBox.Show("Enter an integer");
            }
        }

        //Precondition: Update Day button clicked.
        //Postcondition: The Day is validated and then updated on the date label.
        //               The day textbox is then cleared.
        private void buttonDay_Click(object sender, EventArgs e)
        {
            int day;    //To hold the variable for day.

            //Convert the amount to an int.
            if (int.TryParse(textBoxDay.Text, out day))
            {
                //Input the day into the date variable.
                date.Day = day;

                //Display the date.
                labelOutputDate.Text = date.ToString();

                //Clear the text box.
                textBoxDay.Clear();
            }
            else
            {
                //Display an error message.
                MessageBox.Show("Enter an integer");
            }
        }

        //Precondition: Update Year button clicked.
        //Postcondition: The Year is validated and then updated on the date label.
        //               The year textbox is then cleared.
        private void buttonYear_Click(object sender, EventArgs e)
        {
            int year;   //To hold the variable for year.

            //Convert the amount to an int.
            if (int.TryParse(textBoxYear.Text, out year))
            {
                //Input the year into the date variable.
                date.Year = year;

                //Display the year.
                labelOutputDate.Text = date.ToString();

                //Clear the text box.
                textBoxYear.Clear();
            }
            else
            {
                //Display an error message.
                MessageBox.Show("Enter an integer");
            }
        }
    }
}
