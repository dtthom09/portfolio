﻿namespace Lab8
{
    partial class DateForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelMonth = new System.Windows.Forms.Label();
            this.labelDay = new System.Windows.Forms.Label();
            this.labelYear = new System.Windows.Forms.Label();
            this.textBoxMonth = new System.Windows.Forms.TextBox();
            this.textBoxDay = new System.Windows.Forms.TextBox();
            this.textBoxYear = new System.Windows.Forms.TextBox();
            this.buttonMonth = new System.Windows.Forms.Button();
            this.buttonDay = new System.Windows.Forms.Button();
            this.buttonYear = new System.Windows.Forms.Button();
            this.labelDate = new System.Windows.Forms.Label();
            this.labelOutputDate = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // labelMonth
            // 
            this.labelMonth.AutoSize = true;
            this.labelMonth.Location = new System.Drawing.Point(23, 76);
            this.labelMonth.Name = "labelMonth";
            this.labelMonth.Size = new System.Drawing.Size(40, 13);
            this.labelMonth.TabIndex = 0;
            this.labelMonth.Text = "Month:";
            // 
            // labelDay
            // 
            this.labelDay.AutoSize = true;
            this.labelDay.Location = new System.Drawing.Point(34, 115);
            this.labelDay.Name = "labelDay";
            this.labelDay.Size = new System.Drawing.Size(29, 13);
            this.labelDay.TabIndex = 1;
            this.labelDay.Text = "Day:";
            // 
            // labelYear
            // 
            this.labelYear.AutoSize = true;
            this.labelYear.Location = new System.Drawing.Point(31, 154);
            this.labelYear.Name = "labelYear";
            this.labelYear.Size = new System.Drawing.Size(32, 13);
            this.labelYear.TabIndex = 2;
            this.labelYear.Text = "Year:";
            // 
            // textBoxMonth
            // 
            this.textBoxMonth.Location = new System.Drawing.Point(69, 73);
            this.textBoxMonth.Name = "textBoxMonth";
            this.textBoxMonth.Size = new System.Drawing.Size(100, 20);
            this.textBoxMonth.TabIndex = 3;
            // 
            // textBoxDay
            // 
            this.textBoxDay.Location = new System.Drawing.Point(69, 112);
            this.textBoxDay.Name = "textBoxDay";
            this.textBoxDay.Size = new System.Drawing.Size(100, 20);
            this.textBoxDay.TabIndex = 4;
            // 
            // textBoxYear
            // 
            this.textBoxYear.Location = new System.Drawing.Point(69, 151);
            this.textBoxYear.Name = "textBoxYear";
            this.textBoxYear.Size = new System.Drawing.Size(100, 20);
            this.textBoxYear.TabIndex = 5;
            // 
            // buttonMonth
            // 
            this.buttonMonth.AutoSize = true;
            this.buttonMonth.Location = new System.Drawing.Point(193, 71);
            this.buttonMonth.Name = "buttonMonth";
            this.buttonMonth.Size = new System.Drawing.Size(85, 23);
            this.buttonMonth.TabIndex = 6;
            this.buttonMonth.Text = "Update Month";
            this.buttonMonth.UseVisualStyleBackColor = true;
            this.buttonMonth.Click += new System.EventHandler(this.buttonMonth_Click);
            // 
            // buttonDay
            // 
            this.buttonDay.Location = new System.Drawing.Point(193, 110);
            this.buttonDay.Name = "buttonDay";
            this.buttonDay.Size = new System.Drawing.Size(85, 23);
            this.buttonDay.TabIndex = 7;
            this.buttonDay.Text = "Update Day";
            this.buttonDay.UseVisualStyleBackColor = true;
            this.buttonDay.Click += new System.EventHandler(this.buttonDay_Click);
            // 
            // buttonYear
            // 
            this.buttonYear.Location = new System.Drawing.Point(193, 149);
            this.buttonYear.Name = "buttonYear";
            this.buttonYear.Size = new System.Drawing.Size(85, 23);
            this.buttonYear.TabIndex = 8;
            this.buttonYear.Text = "Update Year";
            this.buttonYear.UseVisualStyleBackColor = true;
            this.buttonYear.Click += new System.EventHandler(this.buttonYear_Click);
            // 
            // labelDate
            // 
            this.labelDate.AutoSize = true;
            this.labelDate.Location = new System.Drawing.Point(66, 30);
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(33, 13);
            this.labelDate.TabIndex = 9;
            this.labelDate.Text = "Date:";
            // 
            // labelOutputDate
            // 
            this.labelOutputDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelOutputDate.Location = new System.Drawing.Point(105, 29);
            this.labelOutputDate.Name = "labelOutputDate";
            this.labelOutputDate.Size = new System.Drawing.Size(100, 23);
            this.labelOutputDate.TabIndex = 10;
            // 
            // DateForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 203);
            this.Controls.Add(this.labelOutputDate);
            this.Controls.Add(this.labelDate);
            this.Controls.Add(this.buttonYear);
            this.Controls.Add(this.buttonDay);
            this.Controls.Add(this.buttonMonth);
            this.Controls.Add(this.textBoxYear);
            this.Controls.Add(this.textBoxDay);
            this.Controls.Add(this.textBoxMonth);
            this.Controls.Add(this.labelYear);
            this.Controls.Add(this.labelDay);
            this.Controls.Add(this.labelMonth);
            this.Name = "DateForm";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Lab8_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelMonth;
        private System.Windows.Forms.Label labelDay;
        private System.Windows.Forms.Label labelYear;
        private System.Windows.Forms.TextBox textBoxMonth;
        private System.Windows.Forms.TextBox textBoxDay;
        private System.Windows.Forms.TextBox textBoxYear;
        private System.Windows.Forms.Button buttonMonth;
        private System.Windows.Forms.Button buttonDay;
        private System.Windows.Forms.Button buttonYear;
        private System.Windows.Forms.Label labelDate;
        private System.Windows.Forms.Label labelOutputDate;
    }
}

