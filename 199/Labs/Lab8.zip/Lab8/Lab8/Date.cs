﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab8
{
    public class Date
    {
        private int _month; //1-12
        private int _day;   //1-31
        private int _year;  //No neg ints

        //Precondition: 1 <= m <= 12
        //              1 <= d <= 31
        //              0 <= y
        //Postcondition: The Date object has been initialized with the specified 
        //               month, day, and year.
        public Date(int m, int d, int y)  //Constructor
        {
            _month = m; //Set the Month property.
            _day = d;   //Set the Day property.
            _year = y;  //Set the Year property.
        }
        public int Month
        {
            //Precondition: None
            //Postcondition: The month has been returned.
            get
            {
                return _month;
            }
            //Precondition: 1 <= value <= 12
            //Postcondition: The month has been set to the specified value.
            set
            {
                if (value >= 1 && value <= 12)
                    _month = value;
            }
        }
        public int Day
        {
            //Precondition: None
            //Postcondition: The day has been returned.
            get
            {
                return _day;
            }
            //Precondition: 1 <= value <= 31
            //Postcondition: The day has been set ti the specified value.
            set
            {
                if (value >= 1 && value <= 31)
                    _day = value;
            }
        }
        public int Year
        {
            //Precondition: None
            //Postcondition: The year has been returned.
            get
            {
                return _year;
            }
            //Precondition: 0 <= value
            //Postcondition: The year has been set to the specified value.
            set
            {
                if (value >= 0)
                    _year = value;
            }
        }
        //Precondition: None
        //Postcondition: A string is returned presenting the date in MM/DD/YYYY format.
        public override string ToString()
        {
            string result;

            result = Month.ToString("D2") + "/" + Day.ToString("D2") + "/" + Year.ToString("D4");

            return result;
        }
    }
}
