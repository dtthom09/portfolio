﻿//By: Dylan Thomas
//Lab 6
//3-8-2016
//CIS 199-01
/* This application displays 4 different patterns of stars*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_6
{
    class Program
    {
        static void Main(string[] args)
        {
            const int MAX_ROWS = 10;  //Constant for the max number of rows.

            //Display star pattern A.
            Console.WriteLine("Pattern A");
            for (int row = 1; row <= MAX_ROWS; row++)
            {
                for (int star = 1; star <= row; star++)
                    Console.Write("*");
                Console.WriteLine();
            }
            //Display star pattern B.
            Console.WriteLine("Pattern B");
            for (int row = MAX_ROWS; row >= 1; row--)
            {
                for (int star = 1; star <= row; star++)
                    Console.Write("*");
                Console.WriteLine();
            }
            //Display star pattern C.
            Console.WriteLine("Pattern C");
            for (int row = MAX_ROWS; row >= 1; row--)
            {
                for (int space = 1; space <= MAX_ROWS-row; space++)
                    Console.Write(" ");
                for (int star = 1; star <= row; star++)
                    Console.Write("*");
                Console.WriteLine();
            }
            //Display star pattern D.
            Console.WriteLine("Pattern D");
            for (int row = 1; row <= MAX_ROWS; row++)
            {
                for (int space = 1; space <= MAX_ROWS-row; space++)
                    Console.Write(" ");
                for (int star = 1; star <= row; star++)
                    Console.Write("*");
                Console.WriteLine();
            }
            Console.WriteLine();



        }
    }
}
