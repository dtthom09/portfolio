﻿namespace Lab1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.FavAnimalPic = new System.Windows.Forms.PictureBox();
            this.NameLabel = new System.Windows.Forms.Label();
            this.HobbiesButton = new System.Windows.Forms.Button();
            this.FavBookButton = new System.Windows.Forms.Button();
            this.FavMovieButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.FavAnimalPic)).BeginInit();
            this.SuspendLayout();
            // 
            // FavAnimalPic
            // 
            this.FavAnimalPic.Image = global::Lab1.Properties.Resources.dog;
            this.FavAnimalPic.Location = new System.Drawing.Point(50, 12);
            this.FavAnimalPic.Name = "FavAnimalPic";
            this.FavAnimalPic.Size = new System.Drawing.Size(200, 100);
            this.FavAnimalPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.FavAnimalPic.TabIndex = 0;
            this.FavAnimalPic.TabStop = false;
            // 
            // NameLabel
            // 
            this.NameLabel.AutoSize = true;
            this.NameLabel.Location = new System.Drawing.Point(108, 127);
            this.NameLabel.Name = "NameLabel";
            this.NameLabel.Size = new System.Drawing.Size(85, 13);
            this.NameLabel.TabIndex = 1;
            this.NameLabel.Text = "Dylan T Thomas";
            this.NameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // HobbiesButton
            // 
            this.HobbiesButton.Location = new System.Drawing.Point(12, 189);
            this.HobbiesButton.Name = "HobbiesButton";
            this.HobbiesButton.Size = new System.Drawing.Size(75, 23);
            this.HobbiesButton.TabIndex = 2;
            this.HobbiesButton.Text = "Hobbies";
            this.HobbiesButton.UseVisualStyleBackColor = true;
            this.HobbiesButton.Click += new System.EventHandler(this.button1_Click);
            // 
            // FavBookButton
            // 
            this.FavBookButton.Location = new System.Drawing.Point(112, 189);
            this.FavBookButton.Name = "FavBookButton";
            this.FavBookButton.Size = new System.Drawing.Size(75, 23);
            this.FavBookButton.TabIndex = 3;
            this.FavBookButton.Text = "Book";
            this.FavBookButton.UseVisualStyleBackColor = true;
            this.FavBookButton.Click += new System.EventHandler(this.button2_Click);
            // 
            // FavMovieButton
            // 
            this.FavMovieButton.Location = new System.Drawing.Point(205, 189);
            this.FavMovieButton.Name = "FavMovieButton";
            this.FavMovieButton.Size = new System.Drawing.Size(75, 23);
            this.FavMovieButton.TabIndex = 4;
            this.FavMovieButton.Text = "Movie";
            this.FavMovieButton.UseVisualStyleBackColor = true;
            this.FavMovieButton.Click += new System.EventHandler(this.button3_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 273);
            this.Controls.Add(this.FavMovieButton);
            this.Controls.Add(this.FavBookButton);
            this.Controls.Add(this.HobbiesButton);
            this.Controls.Add(this.NameLabel);
            this.Controls.Add(this.FavAnimalPic);
            this.Name = "Form1";
            this.Text = "Lab 1";
            ((System.ComponentModel.ISupportInitialize)(this.FavAnimalPic)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox FavAnimalPic;
        private System.Windows.Forms.Label NameLabel;
        private System.Windows.Forms.Button HobbiesButton;
        private System.Windows.Forms.Button FavBookButton;
        private System.Windows.Forms.Button FavMovieButton;
    }
}

