﻿//By: Dylan Thomas
//CIS 199-01
// 2-2-16
//Lab 2
/*This application allows users to type in their title, first, middle, and last name into textboxes.  
 * They can then click on any of the 6 different buttons to display their name in different formats. */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Frmt1Button_Click(object sender, EventArgs e)
        {
            //Create a string variable to hold the entire name.
            string EntireName;
            //Combine the names, w/ a space between them.
            EntireName = TxtboxTitle.Text + " " + Txtbox1stName.Text + " " + TxtboxMidName.Text + " " + TxtboxLstName.Text;
            //Display the EntireName variable in the NameOutputLbl control.
            NameOutputLbl.Text = EntireName;
        }

        private void Frmt2Button_Click(object sender, EventArgs e)
        {
            //Create a string variable to hold the first, middle, and last name.
            string FirstMidLastName;
            //Combine the names, w/ a space between them.
            FirstMidLastName = Txtbox1stName.Text + " " + TxtboxMidName.Text + " " + TxtboxLstName.Text;
            //Display the FirstMidLastName variable in the NameOutputLbl control.
            NameOutputLbl.Text = FirstMidLastName;
        }

        private void Frmt3Button_Click(object sender, EventArgs e)
        {
            //Declare a string variable to hold the full name.
            string fullName;
            //Combine the names, w/ a space between them.
            fullName = Txtbox1stName.Text + " " + TxtboxLstName.Text;
            //Display the fullName variable in the NameOutputLbl control.
            NameOutputLbl.Text = fullName;
        }

        private void Frmt4Button_Click(object sender, EventArgs e)
        {
            //Declare a string variable to hold the LastCommaFirstMidTitle.
            string LastCommaFirstMidTitle;
            //Combine the names, w/ a space between them, a comma after the last name, and a commma after the middle name.
            LastCommaFirstMidTitle = TxtboxLstName.Text + ", " + Txtbox1stName.Text + " " + TxtboxMidName.Text + ", " + TxtboxTitle.Text;
            //Display the LastCommaFirstMidTitle variable in the NameOutputLbl control.
            NameOutputLbl.Text = LastCommaFirstMidTitle;
            
        }

        private void Frmt5Button_Click(object sender, EventArgs e)
        {
            //Declare a string variable to hold the LastCommaFirstMid.
            string LastCommaFirstMid;
            //Combine the names w/ a space between them and a comma after the last name.
            LastCommaFirstMid = TxtboxLstName.Text + ", " + Txtbox1stName.Text + " " + TxtboxMidName.Text;
            //Display the LastCommaFirstMid variable in the NameOutputLbl control.
            NameOutputLbl.Text = LastCommaFirstMid;
        }

        private void Frmt6Button_Click(object sender, EventArgs e)
        {
            //Create a string variable to hold  th LastCommaFirst vairable.
            string LastCommaFirst;
            //Combine the names with a comaa after the last name and a space in between them.
            LastCommaFirst = TxtboxLstName.Text + ", " + Txtbox1stName.Text;
            //Display the LastCommaFirst variable in the NameOutputLbl control.
            NameOutputLbl.Text = LastCommaFirst;
        }
    }
}
