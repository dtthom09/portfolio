﻿namespace Lab2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Txtbox1stName = new System.Windows.Forms.TextBox();
            this.TxtboxMidName = new System.Windows.Forms.TextBox();
            this.TxtboxLstName = new System.Windows.Forms.TextBox();
            this.TxtboxTitle = new System.Windows.Forms.TextBox();
            this.FirstNameLbl = new System.Windows.Forms.Label();
            this.MiddleNameLbl = new System.Windows.Forms.Label();
            this.LastNameLbl = new System.Windows.Forms.Label();
            this.TitleLbl = new System.Windows.Forms.Label();
            this.Frmt1Button = new System.Windows.Forms.Button();
            this.Frmt2Button = new System.Windows.Forms.Button();
            this.Frmt3Button = new System.Windows.Forms.Button();
            this.Frmt4Button = new System.Windows.Forms.Button();
            this.Frmt5Button = new System.Windows.Forms.Button();
            this.Frmt6Button = new System.Windows.Forms.Button();
            this.NameOutputLbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Txtbox1stName
            // 
            this.Txtbox1stName.Location = new System.Drawing.Point(231, 33);
            this.Txtbox1stName.Name = "Txtbox1stName";
            this.Txtbox1stName.Size = new System.Drawing.Size(100, 20);
            this.Txtbox1stName.TabIndex = 0;
            // 
            // TxtboxMidName
            // 
            this.TxtboxMidName.Location = new System.Drawing.Point(231, 62);
            this.TxtboxMidName.Name = "TxtboxMidName";
            this.TxtboxMidName.Size = new System.Drawing.Size(100, 20);
            this.TxtboxMidName.TabIndex = 1;
            // 
            // TxtboxLstName
            // 
            this.TxtboxLstName.Location = new System.Drawing.Point(231, 88);
            this.TxtboxLstName.Name = "TxtboxLstName";
            this.TxtboxLstName.Size = new System.Drawing.Size(100, 20);
            this.TxtboxLstName.TabIndex = 2;
            // 
            // TxtboxTitle
            // 
            this.TxtboxTitle.Location = new System.Drawing.Point(231, 114);
            this.TxtboxTitle.Name = "TxtboxTitle";
            this.TxtboxTitle.Size = new System.Drawing.Size(100, 20);
            this.TxtboxTitle.TabIndex = 3;
            // 
            // FirstNameLbl
            // 
            this.FirstNameLbl.AutoSize = true;
            this.FirstNameLbl.Location = new System.Drawing.Point(154, 36);
            this.FirstNameLbl.Name = "FirstNameLbl";
            this.FirstNameLbl.Size = new System.Drawing.Size(60, 13);
            this.FirstNameLbl.TabIndex = 4;
            this.FirstNameLbl.Text = "First Name:";
            // 
            // MiddleNameLbl
            // 
            this.MiddleNameLbl.AutoSize = true;
            this.MiddleNameLbl.Location = new System.Drawing.Point(142, 65);
            this.MiddleNameLbl.Name = "MiddleNameLbl";
            this.MiddleNameLbl.Size = new System.Drawing.Size(72, 13);
            this.MiddleNameLbl.TabIndex = 5;
            this.MiddleNameLbl.Text = "Middle Name:";
            // 
            // LastNameLbl
            // 
            this.LastNameLbl.AutoSize = true;
            this.LastNameLbl.Location = new System.Drawing.Point(153, 91);
            this.LastNameLbl.Name = "LastNameLbl";
            this.LastNameLbl.Size = new System.Drawing.Size(61, 13);
            this.LastNameLbl.TabIndex = 6;
            this.LastNameLbl.Text = "Last Name:";
            // 
            // TitleLbl
            // 
            this.TitleLbl.AutoSize = true;
            this.TitleLbl.Location = new System.Drawing.Point(25, 117);
            this.TitleLbl.Name = "TitleLbl";
            this.TitleLbl.Size = new System.Drawing.Size(189, 13);
            this.TitleLbl.TabIndex = 7;
            this.TitleLbl.Text = "Preferred title (Mr., Mrs., Ms., Dr., etc.):";
            // 
            // Frmt1Button
            // 
            this.Frmt1Button.Location = new System.Drawing.Point(22, 186);
            this.Frmt1Button.Name = "Frmt1Button";
            this.Frmt1Button.Size = new System.Drawing.Size(75, 23);
            this.Frmt1Button.TabIndex = 8;
            this.Frmt1Button.Text = "Format 1";
            this.Frmt1Button.UseVisualStyleBackColor = true;
            this.Frmt1Button.Click += new System.EventHandler(this.Frmt1Button_Click);
            // 
            // Frmt2Button
            // 
            this.Frmt2Button.Location = new System.Drawing.Point(103, 186);
            this.Frmt2Button.Name = "Frmt2Button";
            this.Frmt2Button.Size = new System.Drawing.Size(75, 23);
            this.Frmt2Button.TabIndex = 9;
            this.Frmt2Button.Text = "Format 2";
            this.Frmt2Button.UseVisualStyleBackColor = true;
            this.Frmt2Button.Click += new System.EventHandler(this.Frmt2Button_Click);
            // 
            // Frmt3Button
            // 
            this.Frmt3Button.Location = new System.Drawing.Point(184, 186);
            this.Frmt3Button.Name = "Frmt3Button";
            this.Frmt3Button.Size = new System.Drawing.Size(75, 23);
            this.Frmt3Button.TabIndex = 10;
            this.Frmt3Button.Text = "Format 3";
            this.Frmt3Button.UseVisualStyleBackColor = true;
            this.Frmt3Button.Click += new System.EventHandler(this.Frmt3Button_Click);
            // 
            // Frmt4Button
            // 
            this.Frmt4Button.Location = new System.Drawing.Point(265, 186);
            this.Frmt4Button.Name = "Frmt4Button";
            this.Frmt4Button.Size = new System.Drawing.Size(75, 23);
            this.Frmt4Button.TabIndex = 11;
            this.Frmt4Button.Text = "Format 4";
            this.Frmt4Button.UseVisualStyleBackColor = true;
            this.Frmt4Button.Click += new System.EventHandler(this.Frmt4Button_Click);
            // 
            // Frmt5Button
            // 
            this.Frmt5Button.Location = new System.Drawing.Point(56, 215);
            this.Frmt5Button.Name = "Frmt5Button";
            this.Frmt5Button.Size = new System.Drawing.Size(75, 23);
            this.Frmt5Button.TabIndex = 12;
            this.Frmt5Button.Text = "Format 5";
            this.Frmt5Button.UseVisualStyleBackColor = true;
            this.Frmt5Button.Click += new System.EventHandler(this.Frmt5Button_Click);
            // 
            // Frmt6Button
            // 
            this.Frmt6Button.Location = new System.Drawing.Point(219, 215);
            this.Frmt6Button.Name = "Frmt6Button";
            this.Frmt6Button.Size = new System.Drawing.Size(75, 23);
            this.Frmt6Button.TabIndex = 13;
            this.Frmt6Button.Text = "Format 6";
            this.Frmt6Button.UseVisualStyleBackColor = true;
            this.Frmt6Button.Click += new System.EventHandler(this.Frmt6Button_Click);
            // 
            // NameOutputLbl
            // 
            this.NameOutputLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.NameOutputLbl.Location = new System.Drawing.Point(28, 147);
            this.NameOutputLbl.Name = "NameOutputLbl";
            this.NameOutputLbl.Size = new System.Drawing.Size(303, 23);
            this.NameOutputLbl.TabIndex = 14;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(352, 273);
            this.Controls.Add(this.NameOutputLbl);
            this.Controls.Add(this.Frmt6Button);
            this.Controls.Add(this.Frmt5Button);
            this.Controls.Add(this.Frmt4Button);
            this.Controls.Add(this.Frmt3Button);
            this.Controls.Add(this.Frmt2Button);
            this.Controls.Add(this.Frmt1Button);
            this.Controls.Add(this.TitleLbl);
            this.Controls.Add(this.LastNameLbl);
            this.Controls.Add(this.MiddleNameLbl);
            this.Controls.Add(this.FirstNameLbl);
            this.Controls.Add(this.TxtboxTitle);
            this.Controls.Add(this.TxtboxLstName);
            this.Controls.Add(this.TxtboxMidName);
            this.Controls.Add(this.Txtbox1stName);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Txtbox1stName;
        private System.Windows.Forms.TextBox TxtboxMidName;
        private System.Windows.Forms.TextBox TxtboxLstName;
        private System.Windows.Forms.TextBox TxtboxTitle;
        private System.Windows.Forms.Label FirstNameLbl;
        private System.Windows.Forms.Label MiddleNameLbl;
        private System.Windows.Forms.Label LastNameLbl;
        private System.Windows.Forms.Label TitleLbl;
        private System.Windows.Forms.Button Frmt1Button;
        private System.Windows.Forms.Button Frmt2Button;
        private System.Windows.Forms.Button Frmt3Button;
        private System.Windows.Forms.Button Frmt4Button;
        private System.Windows.Forms.Button Frmt5Button;
        private System.Windows.Forms.Button Frmt6Button;
        private System.Windows.Forms.Label NameOutputLbl;
    }
}

