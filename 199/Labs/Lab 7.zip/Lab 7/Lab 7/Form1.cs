﻿//By: Dylan Thomas
//Lab 7
//3-29-16
//Display the ticket price for a customer based on the miles driven using arrays.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //Precondition: The distance driven >=0
        private decimal CalcTicketPrice(uint distance)  
        {
            uint[] distLowLimits = { 0, 100, 300, 500 };
            decimal[] prices = { 25, 40, 55, 70 };
            int index;

            index = distLowLimits.Length - 1;
                while (index >= 0 && distance < distLowLimits[index])
                    --index;

                return prices[index];
        }
        //Precondition: OK button clicked.
        private void buttonOK_Click(object sender, EventArgs e)
        {
                uint distance;  //Ticket distance
                decimal price;  //Ticket price

                if (uint.TryParse(textBoxDistance.Text, out distance))
                {
                    price = CalcTicketPrice(distance);
                    labelOutputPrice.Text = price.ToString("C");
                }
                else
                {
                    MessageBox.Show("Enter a non-negative integer distance!");
                }
              //Postcondition: The amount of the ticket is detemine by the amount of miles.
        }
                
    }
}
